"Testing that it's ignoring everything in strings "

public class Test {
	public static void main(String[] args) {
		System.out.println("Data (*/ Structures rocks!} ");
		System.out.println("pls ignore {] this thanks :) "); 	
	}
}
"one { more to ignore"
