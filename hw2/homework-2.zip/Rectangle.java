public class Rectangle implements RectangleInterface, Comparable<Rectangle> { }
